const express = require("express");
const router = express.Router();

router.get("/users", (req, res) => {
    console.log("Controller")

    return res.json({});
});

module.exports = router;